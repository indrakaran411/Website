# 😁 Please make sure to follow this "CONTRIBUTING" guideline before making any contribution to this project.

1. If you found some issue, then please create an issue in the [`Issues`](https://github.com/FahimFBA/RainyRoof_Restaurant_Website/issues) tab.
1. If you want to add a PR, then please create an issue  in the [`Issues`](https://github.com/FahimFBA/RainyRoof_Restaurant_Website/issues) tab describing what you want to implement or improve through your PR.
1. Thanks for your time to contribute to this project. 😊
